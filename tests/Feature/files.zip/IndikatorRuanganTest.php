<?php

namespace Tests\Feature;

use App\Models\IndikatorMutu;
use App\Models\IndikatorRuangan;
use App\Models\Ruangan;
use App\Models\User;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class IndikatorRuanganTest extends TestCase
{
    use DatabaseTransactions;

    protected User $superadmin;

    protected function setUp(): void
    {
        parent::setUp();

        Ruangan::firstOrCreate(['id_ruangan' => 'SP00'], ['nama_ruangan' => 'Superadmin']);
        Ruangan::firstOrCreate(['id_ruangan' => 'R01'], ['nama_ruangan' => 'Ruangan A']);

        IndikatorMutu::create(['id_indikator' => 1, 'variabel' => 'Indikator A', 'standar' => 90]);
        IndikatorMutu::create(['id_indikator' => 2, 'variabel' => 'Indikator B', 'standar' => 85]);

        $this->superadmin = User::create([
            'id_user'      => 'SP001',
            'id_ruangan'   => 'SP00',
            'username'     => 'superadmin',
            'password'     => Hash::make('password'),
            'nama_ruangan' => 'Super Admin',
        ]);
    }

    // F32 - Superadmin bisa assign indikator ke ruangan
    public function test_superadmin_can_assign_indikator_to_ruangan()
    {
        $response = $this->actingAs($this->superadmin)->post(route('superadmin.indikator_ruangan.store'), [
            'id_ruangan'   => 'R01',
            'id_indikator' => 1,
        ]);

        $response->assertRedirect();
        $response->assertSessionHasNoErrors();

        $this->assertDatabaseHas('indikator_ruangan', [
            'id_ruangan'   => 'R01',
            'id_indikator' => 1,
            'active'       => true,
        ]);
    }

    // F33 - Tidak bisa assign indikator yang sama dua kali ke ruangan yang sama
    public function test_cannot_assign_duplicate_active_indikator_to_same_ruangan()
    {
        IndikatorRuangan::create([
            'id_indikator_ruangan' => 1,
            'id_ruangan'           => 'R01',
            'id_indikator'         => 1,
            'active'               => true,
        ]);

        $response = $this->actingAs($this->superadmin)->post(route('superadmin.indikator_ruangan.store'), [
            'id_ruangan'   => 'R01',
            'id_indikator' => 1,
        ]);

        // Harus ada error atau redirect dengan pesan error
        $response->assertSessionHasErrors();
    }

    // F34 - Superadmin bisa menonaktifkan indikator_ruangan
    public function test_superadmin_can_deactivate_indikator_ruangan()
    {
        $indikatorRuangan = IndikatorRuangan::create([
            'id_indikator_ruangan' => 1,
            'id_ruangan'           => 'R01',
            'id_indikator'         => 1,
            'active'               => true,
        ]);

        $response = $this->actingAs($this->superadmin)->patch(
            route('superadmin.indikator_ruangan.deactivate', $indikatorRuangan->id_indikator_ruangan)
        );

        $response->assertRedirect();

        $this->assertDatabaseHas('indikator_ruangan', [
            'id_indikator_ruangan' => 1,
            'active'               => false,
        ]);
    }

    // F35 - Superadmin bisa ganti indikator (old nonaktif, new aktif)
    public function test_superadmin_can_switch_indikator()
    {
        $oldIndikator = IndikatorRuangan::create([
            'id_indikator_ruangan' => 1,
            'id_ruangan'           => 'R01',
            'id_indikator'         => 1,
            'active'               => true,
        ]);

        $response = $this->actingAs($this->superadmin)->post(route('superadmin.indikator_ruangan.switch'), [
            'id_indikator_ruangan_lama' => $oldIndikator->id_indikator_ruangan,
            'id_ruangan'                => 'R01',
            'id_indikator'              => 2,
        ]);

        $response->assertRedirect();

        $this->assertDatabaseHas('indikator_ruangan', [
            'id_indikator_ruangan' => 1,
            'active'               => false,
        ]);

        $this->assertDatabaseHas('indikator_ruangan', [
            'id_ruangan'   => 'R01',
            'id_indikator' => 2,
            'active'       => true,
        ]);
    }

    // F36 - Halaman edit hanya menampilkan indikator aktif
    public function test_edit_page_shows_only_active_indikators()
    {
        $activeIndikator = IndikatorRuangan::create([
            'id_indikator_ruangan' => 1,
            'id_ruangan'           => 'R01',
            'id_indikator'         => 1,
            'active'               => true,
        ]);

        IndikatorRuangan::create([
            'id_indikator_ruangan' => 2,
            'id_ruangan'           => 'R01',
            'id_indikator'         => 2,
            'active'               => false,
        ]);

        $response = $this->actingAs($this->superadmin)->get(
            route('superadmin.indikator_ruangan.edit', 'R01')
        );

        $response->assertStatus(200);
        $response->assertSee('Indikator A');
        $response->assertDontSee('Indikator B');
    }
}
